"""Version information for sageTSDB."""

__version__ = "0.1.3"
__author__ = "SAGE Team"
__email__ = "shuhao_zhang@hust.edu.cn"
